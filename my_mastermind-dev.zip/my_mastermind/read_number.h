#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

char  *read_number(char* input){
     int var_4 = 0;
     int var_5 =0;
     char var_6;
     while ((var_4 = read(0, &var_6, 1) > 0)) {
         if(var_6 == '\n'){
             return input;
         }
         input[var_5] = var_6;
         var_5++;
     }
     return 0;
 }

 